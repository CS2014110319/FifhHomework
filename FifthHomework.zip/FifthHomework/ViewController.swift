//
//  ViewController.swift
//  FifthHomework
//
//  Created by student on 2018/10/10.
//  Copyright © 2018年 lishunli. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var label:UILabel!
    var button:UIButton!
    var image:UIImage!
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.black
        button = UIButton(frame: CGRect(x: 150, y: 150, width: 100, height: 100))
        button.setTitle("Click me", for: .normal)
        button.setTitleColor(UIColor.green, for: .normal)
        button.addTarget(self, action: #selector(clicked), for: .touchUpInside)
        view.addSubview(button)
        
        
        
        label = UILabel(frame: CGRect(x: 100, y: 250, width: 200, height: 100))
        label.text = "LslLabel"
        label.backgroundColor = UIColor.green
        label.textAlignment = .center
        view.addSubview(label)
  
        
        let imageView = UIImageView(frame: CGRect(x: 100, y: 400, width: 200, height: 200))
        imageView.image = UIImage(named: "picture")
        view.addSubview(imageView)
    }
    @IBAction func clicked(){
        if label.text! == "LslLabel"{
            label.text = "Hello Word"
        }else{
            label.text = "LslLabel"
        }
        func didReceiveMemoryWarning(){
            super.didReceiveMemoryWarning()
        }
    }

}

